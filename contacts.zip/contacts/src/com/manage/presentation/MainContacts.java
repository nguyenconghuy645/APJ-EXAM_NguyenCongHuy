package com.manage.presentation;

import com.manage.model.Contacts;
import com.manage.service.ContactsService;

import java.io.IOException;
import java.util.Scanner;

public class MainContacts {
    public static void main(String[] args) {
        ContactsService contactsService = new ContactsService();
        Scanner scanner = new Scanner(System.in);
        try {
            contactsService.loadFileContacts();
        } catch (IOException e) {
            System.err.println("Customer Manager File is Empty!");
        }
        int choose;
        do{
            contactsService.printContactsMenu();
            choose = scanner.nextInt();
            switch (choose){
                case 1:
                    try {
                        contactsService.showFileContacts();
                    } catch (IOException e) {
                        System.err.println(e.getMessage());
                    }
                    break;
                case 2:
                    try {
                        contactsService.addContact();
                    } catch (IOException e) {
                        System.err.println(e.getMessage());
                    }
                    break;
                case 3:
                    try {
                        contactsService.updateFileContacts();
                    } catch (IOException e) {
                        System.err.println(e.getMessage());
                    }
                    break;
                case 4:
                    try {
                        contactsService.deleteContact();
                    } catch (IOException e) {
                        System.err.println("Customer Manager File is Empty!");
                    }
                    break;
                case 5:
                    try {
                        contactsService.searchContact();
                    } catch (IOException e) {
                        System.err.println(e.getMessage());
                    }
                    break;
                case 6:
                    try {
                        contactsService.readFromContacts();
                    } catch (IOException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 7:
                    try {
                        contactsService.writeToContacts();
                    } catch (IOException e) {
                        System.err.println(e.getMessage());
                    }
                    break;
                case 8:
                    System.out.println("Thoát.");
                    break;
                default:
                    System.out.println("Moi nhap lai!");
                    System.out.println("------------");
                    break;
            }
        }while (choose != 8);
    }
}
