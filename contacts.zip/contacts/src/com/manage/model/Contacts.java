package com.manage.model;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Contacts {
    private int id;
    private int telephone;
    private String contactGroup, fullName, gender, address, dateOfBirth, email;
    Scanner scanner = new Scanner(System.in);

    public Contacts() {

    }

    public Contacts(int telephone, String contactGroup, String fullName, String gender, String address, String dateOfBirth, String email) {
        this.telephone = telephone;
        this.contactGroup = contactGroup;
        this.fullName = fullName;
        this.gender = gender;
        this.address = address;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTelephone() {
        return telephone;
    }

    public void setTelephone(int telephone) {
        this.telephone = telephone;
    }

    public String getContactGroup() {
        return contactGroup;
    }

    public void setContactGroup(String contactGroup) {
        this.contactGroup = contactGroup;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Contacts{" +
                "telephone=" + telephone +
                ", contactGroup='" + contactGroup + '\'' +
                ", fullName='" + fullName + '\'' +
                ", gender='" + gender + '\'' +
                ", address='" + address + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                ", email='" + email + '\'' +
                '}';
    }

    public String toStringCSV() {
        return telephone +
                "," + contactGroup +
                "," + fullName +
                "," + gender +
                "," + address +
                "," + dateOfBirth +
                "," + email + "\n";
    }

    public void inputcontacts() {
        String regexTelephone = "^(0?)(3[2-9]|5[6|8|9]|7[0|6-9]|8[0-6|8|9]|9[0-4|6-9])[0-9]{7}$";
        System.out.println("Enter the telephone: ");
        String telephone = scanner.nextLine();
        Pattern pattern1 = Pattern.compile(regexTelephone);
        Matcher matcher1 = pattern1.matcher(telephone);
        while (!matcher1.find()) {
            System.out.println("Please input right format for telephone!");
            telephone = scanner.nextLine();
            matcher1 = pattern1.matcher(telephone);
        }
        this.telephone = Integer.parseInt(telephone);
        System.out.println("Enter the contact group: ");
        this.contactGroup = scanner.nextLine();
        System.out.println("Enter the full name: ");
        this.fullName = scanner.nextLine();
        System.out.println("Enter the gender: ");
        this.gender = scanner.nextLine();
        System.out.println("Enter the address: ");
        this.address = scanner.nextLine();
        System.out.println("Enter the date of birth: ");
        this.dateOfBirth = scanner.nextLine();
        String regexEmail ="^\\w[a-z0-9]*@[a-z0-9]*.[a-z0-9]*$";
        System.out.println("Enter the email: ");
        this.email = scanner.nextLine();
        Pattern pattern2 = Pattern.compile(regexEmail);
        Matcher matcher2 = pattern2.matcher(this.email);
        while(!matcher2.find()) {
            System.out.println("Please input right format for email!");
            this.email= scanner.nextLine();
            matcher2 = pattern2.matcher(this.email);
        }
    }

    public void displayContactEmail(){
        System.out.printf("|| %15s | %20s | %30s | %11s | %20s | %15s | %30s ||",telephone,contactGroup,fullName,gender,address,dateOfBirth,email);
        System.out.println();
    }
    public void displayContactNonEmail(){
        System.out.printf("|| %15s | %20s | %30s | %11s | %20s | %15s ||",telephone,contactGroup,fullName,gender,address,dateOfBirth);
        System.out.println();
    }
    public void printContact(){

    }

}
