package com.manage.service;

import com.manage.dal.ContactsDB;
import com.manage.model.Contacts;

import java.io.IOException;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.manage.dal.ContactsDB.contactsList;

public class ContactsService {
    ContactsDB contactsDB = new ContactsDB();
    Contacts contacts = new Contacts();
    Scanner scanner = new Scanner(System.in);

    public void loadFileContacts() throws IOException {
        contactsDB.loadFileContacts();
    }

    public  static void printContactsMenu(){
        System.out.println(
                """
                        ----- CHƯƠNG TRÌNH QUẢN LÝ DANH BẠ -----
                        Chọn chức năng theo số (để tiếp tục):
                        1. Xem danh sách
                        2. Thêm mới
                        3. Cập nhật
                        4. Xóa
                        5. Tìm kiếm
                        6. Đọc từ file
                        7. Ghi vào file
                        8. Thoát
                        Chọn chức năng:
                        """);
    }

    public void showFileContacts() throws IOException {
        int size = contactsDB.contactsList.size();
        if (size==0){
            System.out.println("Contact not exists.");
        }else {
            printContactNonEmail();
            for (int i = 0; i < size; i++) {
                if (i==0 || i%5!=0){
                    contactsDB.contactsList.get(i).displayContactNonEmail();
                }else {
                    System.out.println("Press enter to continue displaying the list: ");
                    switch (scanner.nextLine()){
                        case "":
                            printContactNonEmail();
                            contactsDB.contactsList.get(i).displayContactNonEmail();
                            break;
                        default:
                            System.out.println("Exit. ");
                            return;
                    }
                }
            }
            System.out.println("Displayed all contacts!!!");
        }
    }

    public void addContact() throws IOException {
        contacts.inputcontacts();
        for (Contacts contact : contactsList) {
            if (contact.getEmail().equals(contacts.getEmail()) || contact.getTelephone() == contacts.getTelephone()) {
                System.out.println("Contact exists, system is update\n" + "==========================================\n");
                return;
            }
        }
        int count = contactsList.size();
        contacts.setId(++count);
        contactsList.add(contacts);
        System.out.println("Add complete!");
        System.out.println(contactsList.getLast());
        System.out.println("------------");
        contactsDB.saveFileContacts();
    }

    public void updateFileContacts() throws IOException {
        if (contactsList.size() == 0) {
            System.err.println("Contacts File is Empty!");
            return;
        }
        boolean check = true;
        int telephone = getTelephone();
        for (Contacts contact : contactsList) {
            if (contact.getTelephone() == telephone) {
                contact.inputcontacts();
                System.out.println("Result: " + contactsList.getLast());
                contactsDB.saveFileContacts();
                check = false;
            }
        }
        if (check) {
            System.out.println("Contacts not exists \n" + "==========================================\n" + "\n");
        }
    }

    public void deleteContact() throws IOException {
        if (contactsList.size() == 0) {
            System.err.println("Contacts File is Empty!");
            return;
        }
        boolean check = true;
        int telephone = getTelephone();
        for (Contacts contact : contactsList) {
            if (contact.getTelephone() == telephone) {
                System.out.println("Request confirmation that you want to delete contact information, Press Y if you agree:");
                String confirm = scanner.nextLine();
                switch (confirm) {
                    case "Y":
                        contactsList.remove(contact);
                        System.out.println("Delete complete!");
                        System.out.println("                                          --------------");
                        contactsDB.saveFileContacts();
                        check = false;
                        break;
                    default:
                        break;
                }
            }
        }
        if (check) {
            System.out.println("Contacts not exists \n" + "==========================================\n" + "\n");
        }
    }

    public void searchContact() throws IOException {
        if (contactsList.size() == 0) {
            System.err.println("Contacts File is Empty!");
            return;
        }
        int telephone = getTelephone();
        System.out.println("System is searching\n" + "result:\n");
        boolean check = true;
        for (Contacts contact : contactsList) {
            if (contact.getTelephone() == telephone) {
                System.out.println(contact.toString());
                check = false;
                break;
            }
        }
        if (check) {
            System.out.println("Contacts not exists \n" + "==========================================\n" + "\n");
        }
    }

    public void readFromContacts() throws IOException {
        System.out.println("Warning deleting all contacts currently in memory!!!\n" + "Press Y if you agree:");
        String confirm = scanner.nextLine();
        switch (confirm) {
            case "Y":
                contactsDB.readFileContacts();
                break;
            default:
                break;
        }
    }

    public void writeToContacts() throws IOException {
        System.out.println("Warning users before updating contacts file!!!\n" + "Press Y if you agree:");
        String confirm = scanner.nextLine();
        switch (confirm) {
            case "Y":
                contactsDB.saveFileContacts();
                break;
            default:
                break;
        }
    }

    private int getTelephone() {
        String regex = "^(0?)(3[2-9]|5[6|8|9]|7[0|6-9]|8[0-6|8|9]|9[0-4|6-9])[0-9]{7}$";
        System.out.println("Enter the telephone: ");
        String telephone = scanner.nextLine();
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(telephone);
        while (!matcher.find()) {
            System.out.println("Please input right format for telephone!");
            telephone = scanner.nextLine();
            matcher = pattern.matcher(telephone);
        }
        return Integer.parseInt(telephone);
    }

    public void printContactEmail(){
        System.out.printf("|| %15s | %20s | %30s | %11s | %20s | %15s | %30s ||","Số điện thoại","Nhóm danh bạ","Họ tên","Giới tính","Địa chỉ","Ngày sinh","Email");
        System.out.println();
    }
    public void printContactNonEmail(){
        System.out.printf("|| %15s | %20s | %30s | %11s | %20s | %15s ||","Số điện thoại","Nhóm danh bạ","Họ tên","Giới tính","Địa chỉ","Ngày sinh");
        System.out.println();
    }
}
