package com.manage.dal;

import com.manage.model.Contacts;

import java.io.*;
import java.util.LinkedList;

public class ContactsDB {
    public static LinkedList<Contacts> contactsList = new LinkedList<>();

    public void saveFileContacts() throws IOException {
        FileWriter fileWriter = new FileWriter("E:\\Codegym\\Time\\C0221H1\\Timework\\Module2\\manage\\data\\contacts.csv");
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        for (Contacts contact : contactsList) {
            String line = contact.toStringCSV();
            bufferedWriter.write(line);
        }
        bufferedWriter.close();
    }

    public void readFileContacts() throws IOException {
        LinkedList<Contacts> printContactsList = new LinkedList<>();
        FileReader fileReader = new FileReader("E:\\Codegym\\Time\\C0221H1\\Timework\\Module2\\manage\\data\\contacts.csv");
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            String[] arr = line.split(",");
            if (arr[0].equals("ID")) {
                continue;
            }
            try {
                Contacts contacts = new Contacts(Integer.parseInt(arr[0]), arr[1], arr[2], arr[3], arr[4], arr[5], arr[6]);
                printContactsList.add(contacts);
            } catch (ArrayIndexOutOfBoundsException ignored) {
                System.out.println(ignored.getMessage());
            }
        }
        for (Contacts contact : printContactsList) {
            System.out.println(contact.toString());
        }
        System.out.println();
        bufferedReader.close();
    }

    public void loadFileContacts() throws IOException {
        FileReader fileReader = new FileReader("E:\\Codegym\\Time\\C0221H1\\Timework\\Module2\\manage\\data\\contacts.csv");
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            String[] arr = line.split(",");
            if (arr[0].equals("ID")) {
                continue;
            }
            try {
                Contacts contacts = new Contacts(Integer.parseInt(arr[0]), arr[1], arr[2], arr[3], arr[4], arr[5], arr[6]);
                contactsList.add(contacts);
            } catch (ArrayIndexOutOfBoundsException ignored) {
                System.out.println(ignored.getMessage());
            }
        }
    }
}
